# Load libraries ----------
library(SWMPrExtension)
library(dplyr)
library(tidyr)
library(mapview)
library(readxl)

# Set common variables -----
#### Reserve related 
data.loc <- 'data/'
res <- get_reserve(data.file = data.loc)
res_abb <- get_site_code(data.file = data.loc)

#### Variable spreadsheet related
wb_name <- 'figure_files/Reserve_Level_Plotting_Variables.xlsx'
sheets <- c('Flags', 'Years_of_Interest', 'Seasons', 'Mapping', 'Bonus_Settings'
            , 'Basic_Plotting', 'Threshold_Plots', 'Threshold_Identification')

## DEFINE YEARS OF INTEREST ---- DLE, 8/7/2019: Always read these two, even if already defined
year_range <- read_xlsx(path = wb_name, sheet = sheets[2])[[1]]
target_year <- read_xlsx(path = wb_name, sheet = sheets[2])[[2]][1]

# DEFINE FLAGS TO KEEP ----
keep_flags <- read_xlsx(path = wb_name, sheet = sheets[1])[[1]]

## DETERMINE CALCULATED & CONVERTED PARAMETERS ----
wb <- read_xlsx(path = wb_name, sheet = sheets[5])

#### Convert temperature values from C to F?
convert_temp <- wb[[2]][1] %>% as.logical

#### Convert precipitation from mm to in?
convert_precip <- wb[[2]][2] %>% as.logical

#### Convert precipitation from mm to in?
convert_depth <- wb[[2]][3] %>% as.logical

#### Calculate dissolved inorganic phosphorus?
#### Calcuated as dip = po4f
calc_dip <- wb[[2]][6] %>% as.logical

#### Calculate dissolved inorganic nitrogen?
#### Calculated as din <- no2f + no3f + nh4f
calc_din <- wb[[2]][7] %>% as.logical
calc_no23 <- wb[[2]][8] %>% as.logical

#### Include station labels on maps?
res_map_station_labels <- wb[[2]][9] %>% as.logical
sk_map_station_labels <- wb[[2]][10] %>% as.logical

## DEFINE PLOTTING VARIABLES -----
include_station_ttl <- wb[[2]][4] %>% as.logical
include_hist_avg <- wb[[2]][5] %>% as.logical

# Set mapping variables ----
wb <- read_xlsx(path = wb_name, sheet = sheets[4])

#### Reserve bounding box
res_bbox <- wb[[1]] %>% .[complete.cases(.)]
sk_bbox <- wb[[2]] %>% .[complete.cases(.)]

#### shapefile parameters
res_gis_loc <- paste('inst/gis/GIS_Process/', toupper(res_abb), '/Boundaries/Reserve_Boundaries', sep = '')
res_gis_shp <- get_shp_name(res_gis_loc)

# Load spatial data
res_spatial <- load_shp_file(path = paste(res_gis_loc, res_gis_shp, sep ='/'), dissolve = T)

sites_to_map <- get_sites('data/') %>% .[grep('wq|nut', .)]
sites_to_map <- geographic_unique_stations(sites_to_map)
sites_to_map <- c(sites_to_map, get_sites('data/') %>% .[grep('met', .)])
sites_to_map <- sites_to_map[!duplicated(sites_to_map)]

scale_pos <- 'bottomleft'
map_labels <- wb[[3]] %>% .[complete.cases(.)]

wq_trend_labs <- wb[[4]] %>% .[complete.cases(.)]
met_trend_labs <- wb[[5]] %>% .[complete.cases(.)]
nut_trend_labs <- wb[[6]] %>% .[complete.cases(.)]
